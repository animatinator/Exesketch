// object.cpp

#include "object.h"


float Object::pixelSize = 2.0f;

Object::Object(int obType):
	type(obType),
	pos(Vector2d(0.0f, 0.0f)),
	selected(false),
	dragging(false),
	state(OBJECT_VIEW)
{}

Object::Object(const Vector2d& startPos, int obType):
	type(obType),
	pos(startPos),
	selected(false),
	dragging(false),
	state(OBJECT_VIEW)
{}

void Object::HandleEvent(const Event& event)
{
	if (event.type == EVENT_MOUSE_DOWN_LEFT)
	{
		if (MouseHitObject(event.realxpos, event.realypos) && !event.HasFoundTarget())
		{
			selected = true;
			dragging = true;
			oldPos = pos;
			storedMouse = Vector2d(event.realxpos, event.realypos);
		}
		else
		{
			if (state != EDITING && event.modifiers != GLUT_ACTIVE_SHIFT) selected = false;
		}
	}
	
	else if (event.type == EVENT_MOUSE_UP_LEFT)
	{
		dragging = false;
	}
	
	else if (event.type == EVENT_MOUSE_MOTION)
	{
		if (selected && dragging)
		{
			Vector2d currentMouse(event.realxpos, event.realypos);
			pos = oldPos + (currentMouse - storedMouse);
		}
	}
	
	else if (event.type == EVENT_KEYBOARD_K_TAB)
	{
		if (selected && (state != EDITING)) state = EDITING;
		else state = OBJECT_VIEW;
	}
}

void Object::DrawHandle(const Vector2d& pos)
{
	float i = pixelSize * HANDLE_SIZE;
	float x = pos.x; float y = pos.y;
	
	glBegin(GL_LINE_LOOP);
		glVertex2f(x - i, y - i);
		glVertex2f(x + i, y - i);
		glVertex2f(x + i, y + i);
		glVertex2f(x - i, y + i);
	glEnd();
}

void Object::DrawBoundingBox()
{
	Vector2d min = GetMin();
	Vector2d max = GetMax();
	
	glColor3f(0.0f, 0.3f, 0.7f);
	
	glBegin(GL_LINE_LOOP);
		glVertex2f(min.x, min.y);
		glVertex2f(max.x, min.y);
		glVertex2f(max.x, max.y);
		glVertex2f(min.x, max.y);
	glEnd();
}
