// polygon.h


#ifndef POLYGON_H
#define POLYGON_H

#include <vector>

#include "object.h"
#include "vector2d.h"

class Event;


class Polygon : public Object
{
	public:
		Polygon();
		Polygon(const Vector2d& startPos);
		Polygon(const Polygon& other);
		
		void InitShape();
		
		virtual void Draw();
		virtual void HandleEvent(const Event& event);
		virtual bool MouseHitObject(float x, float y) const;
		
		int MouseHitHandle(float x, float y) const;
		
		virtual Vector2d GetMin() const;
		virtual Vector2d GetMax() const;
		
		virtual Object* CreateCopy();
	
	protected:
		vector<Vector2d> points;
		int selectIndex;
		bool dragPoint;
		
		bool fill;
};

#endif
