// object.h


#ifndef OBJECT_H
#define OBJECT_H

#include "vector2d.h"
#include "event.h"


class Event;

enum OBJECT {RECT = 0, POLYGON};


class Object
{
	public:
		Object();
		Object(const Vector2d& startpos);
		
		bool IsSelected() const {return selected;}
		int GetState() const {return state;}
		
		virtual void Draw() = 0;
		virtual void HandleEvent(const Event& event);
		virtual bool MouseHitObject(float x, float y) = 0;
		
		void Select() {selected = true;}
		void Deselect() {selected = false;}
	
	protected:
		Vector2d pos, oldPos;
		int state;
		bool selected, dragging;
		Vector2d storedMouse;
};

#endif
