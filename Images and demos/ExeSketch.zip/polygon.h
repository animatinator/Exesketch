// polygon.h


#ifndef POLYGON_H
#define POLYGON_H

#include <vector>

#include "object.h"
#include "vector2d.h"

class Event;


class Polygon : public Object
{
	public:
		Polygon();
		Polygon(const Vector2d& startPos);
		Polygon(const Polygon& other);
	
	protected:
		vector<Vector2d> points;
		int selectIndex;
		bool dragPoint;
};

#endif
