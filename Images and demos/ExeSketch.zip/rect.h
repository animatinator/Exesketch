// rect.h


#ifndef RECT_H
#define RECT_H
#include "object.h"


class Event;


enum HANDLE_TYPE {NONE = 0, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT};

class Rect : public Object
{
	public:
		Rect();
		Rect(const Vector2d& startPos, float startWidth = 50.0f, float startHeight = 50.0f);
		Rect(const Rect& other);
		
		virtual void Draw();
		virtual void HandleEvent(const Event& event);
		virtual bool MouseHitObject(float x, float y);
		
		void DrawHandle(float x, float y);
		int MouseHitHandle(float x, float y);
		
		void EndHandleDrag();
	
	protected:
		float width, oldWidth;
		float height, oldHeight;
		
		int selectedHandle;
		bool dragHandle;
		
		bool fill;
};

#endif
