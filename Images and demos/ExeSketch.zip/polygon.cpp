//polygon.cpp


#include "polygon.h"


Polygon::Polygon():
	Object(),
	selectIndex(0),
	dragPoint(false)
{}

Polygon::Polygon(const Vector2d& startPos):
	Object(startPos),
	selectIndex(0),
	dragPoint(false)
{}

Polygon::Polygon(const Polygon& other):
	Object(other.pos),
	points(other.points),
	selectIndex(other.selectIndex),
	dragPoint(other.dragPoint)
{}
