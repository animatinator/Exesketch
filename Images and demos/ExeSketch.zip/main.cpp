// main.cpp


#include <iostream>
#include <cstdlib>

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

#include "main.h"

using namespace std;


int width = 800;
int height = 600;

ObjectDisplay* objectDisplay;
EventHandler* events;
ObjectManager* objects;


void InitRendering()
{
	glDisable(GL_DEPTH_TEST);
	glClearColor(1.0, 1.0, 1.0, 1.0);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, height, 0, 0, 1);
	
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glHint (GL_LINE_SMOOTH_HINT, GL_DONT_CARE);
}

void WindowResize(int w, int h)
{
	glViewport(0, 0, w, h);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, height, 0, 0, 1);
	
	width = w;
	height = h;
}

void HandleMouseButton(int button, int state, int x, int y)
{
	int modifiers = glutGetModifiers();
	
	int eventType = NA;
	
	if (state == GLUT_DOWN)
	{
		if (button == GLUT_LEFT_BUTTON) eventType = EVENT_MOUSE_DOWN_LEFT;
		else if (button == GLUT_MIDDLE_BUTTON) eventType = EVENT_MOUSE_DOWN_MIDDLE;
		else if (button == GLUT_RIGHT_BUTTON) eventType = EVENT_MOUSE_DOWN_RIGHT;
	}
	else if (state == GLUT_UP)
	{
		if (button == GLUT_LEFT_BUTTON) eventType = EVENT_MOUSE_UP_LEFT;
		else if (button == GLUT_MIDDLE_BUTTON) eventType = EVENT_MOUSE_UP_MIDDLE;
		else if (button == GLUT_RIGHT_BUTTON) eventType = EVENT_MOUSE_UP_RIGHT;
	}
	
	Event newEvent(eventType, modifiers, x, y);
	events->AddEvent(newEvent);
}

void HandleMouseMotion(int x, int y)
{
	Event newEvent(EVENT_MOUSE_MOTION, NA, x, y);
	events->AddEvent(newEvent);
}

void HandlePassiveMouseMotion(int x, int y)
{
	Event newEvent(EVENT_MOUSE_MOTION, NA, x, y);
	events->AddEvent(newEvent);
}

void HandleKeyPress(unsigned char key, int x, int y)
{
	int modifiers = glutGetModifiers();
	
	switch(key)
	{
		case 27:  // Escape key
			exit(0);
			break;
		
		case 127:
		{
			Event newEvent(EVENT_KEYBOARD_K_DEL, modifiers);
			events->AddEvent(newEvent);
			break;
		}
		
		case '\t':
		{
			Event newEvent(EVENT_KEYBOARD_K_TAB, modifiers);
			events->AddEvent(newEvent);
			break;
		}
		
		default:
		{
			int eventType = NO_EVENT;
			
			// 7 onwards = key events
			if (key > 64 && key < 91)  // Uppercase
			{
				eventType = (key - 65) + EVENT_KEYBOARD_K_A;
			}
			else if (key > 96 && key < 123)  // Lowercase
			{
				eventType = (key - 97) + EVENT_KEYBOARD_K_A;
			}
			
			if (eventType != NO_EVENT)
			{
				Event newEvent(eventType, modifiers);
				events->AddEvent(newEvent);
			}
			
				break;
		}
	}
}

void HandleSpecialKeyPress(int key, int x, int y)
{
	int modifiers = glutGetModifiers();
	int eventType = NO_EVENT;
	
	switch(key)
	{
		case GLUT_KEY_UP:
			eventType = EVENT_KEYBOARD_K_UP;
			break;
		
		case GLUT_KEY_DOWN:
			eventType = EVENT_KEYBOARD_K_DOWN;
			break;
		
		case GLUT_KEY_LEFT:
			eventType = EVENT_KEYBOARD_K_LEFT;
			break;
		
		case GLUT_KEY_RIGHT:
			eventType = EVENT_KEYBOARD_K_RIGHT;
			break;
		
		default:
			break;
	}
	
	if (eventType != NO_EVENT)
	{
		Event newEvent(eventType, modifiers);
		events->AddEvent(newEvent);
	}
}

void CreateObject(float x, float y)
{
	objects->DeselectAll();
	Object* newObject = NULL;
	Vector2d pos(x, y);
	
	switch(objects->GetAddObject())
	{
		case RECT:
			newObject = new Rect(pos);
			newObject->Select();
				break;
		
		default:
			break;
	}
	
	if (newObject) objects->AddObject(newObject);
}

void DrawScene()
{
	glClear(GL_COLOR_BUFFER_BIT);
	
	objectDisplay->DrawObjects();
	
	glutSwapBuffers();
}

void Update(int value)
{
	events->ProcessQueue();
	objectDisplay->Update();
	
	switch(objects->GetState())
	{
		case OBJECT_VIEW:
			glutSetWindowTitle("ExeSketch - Object View mode");
				break;
		
		case EDITING:
			glutSetWindowTitle("ExeSketch - Editing mode");
				break;
	}
	
	queue<Event> currentEvents = events->GetEvents();
	
	while (!currentEvents.empty())
	{
		Event current = currentEvents.front();
		
		if (current.type == EVENT_MOUSE_DOWN_RIGHT && objects->GetState() == OBJECT_VIEW)
		{
			CreateObject(current.realxpos, current.realypos);
		}
		
		currentEvents.pop();
	}
	
	glutPostRedisplay();
	glutTimerFunc((int)(1000.0 / 30.0), Update, 0);
}


int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	
	glutInitWindowSize(width, height);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("ExeSketch");
	
	InitRendering();
	
	objectDisplay = new ObjectDisplay();
	events = new EventHandler(objectDisplay);
	
	objects = new ObjectManager();
	objectDisplay->AddClient(objects);
	events->RegisterClient(objects);
	objectDisplay->SetOffset(Vector2d(-400.0f, -300.0f));
	
	glutDisplayFunc(DrawScene);
	glutReshapeFunc(WindowResize);
	glutMouseFunc(HandleMouseButton);
	glutMotionFunc(HandleMouseMotion);
	glutPassiveMotionFunc(HandlePassiveMouseMotion);
	glutKeyboardFunc(HandleKeyPress);
	glutSpecialFunc(HandleSpecialKeyPress);
	
	glutTimerFunc(25, Update, 0);
	
	glutMainLoop();
	
		return 0;
}
