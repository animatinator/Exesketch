// object.cpp

#include "object.h"


Object::Object():
	pos(Vector2d(0.0f, 0.0f)),
	selected(false),
	dragging(false),
	state(OBJECT_VIEW)
{}

Object::Object(const Vector2d& startPos):
	pos(startPos),
	selected(false),
	dragging(false),
	state(OBJECT_VIEW)
{}

void Object::HandleEvent(const Event& event)
{
	if (event.type == EVENT_MOUSE_DOWN_LEFT)
	{
		if (MouseHitObject(event.realxpos, event.realypos) && !event.HasFoundTarget())
		{
			selected = true;
			dragging = true;
			oldPos = pos;
			storedMouse = Vector2d(event.realxpos, event.realypos);
		}
		else
		{
			if (state != EDITING && event.modifiers != GLUT_ACTIVE_SHIFT) selected = false;
		}
	}
	
	else if (event.type == EVENT_MOUSE_UP_LEFT)
	{
		dragging = false;
	}
	
	else if (event.type == EVENT_MOUSE_MOTION)
	{
		if (selected && dragging)
		{
			Vector2d currentMouse(event.realxpos, event.realypos);
			pos = oldPos + (currentMouse - storedMouse);
		}
	}
	
	else if (event.type == EVENT_KEYBOARD_K_TAB)
	{
		if (selected && (state != EDITING)) state = EDITING;
		else state = OBJECT_VIEW;
	}
}
