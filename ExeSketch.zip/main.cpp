// main.cpp


#include <iostream>
#include <cstdlib>

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

#include "main.h"

using namespace std;


int width = 800;
int height = 600;

ObjectDisplay* objectDisplay;
EventHandler* events;


void InitRendering()
{
	glDisable(GL_DEPTH_TEST);
	glClearColor(1.0, 1.0, 1.0, 1.0);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, height, 0, 0, 1);
	
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glHint (GL_LINE_SMOOTH_HINT, GL_DONT_CARE);
}

void WindowResize(int w, int h)
{
	glViewport(0, 0, w, h);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, height, 0, 0, 1);
	
	width = w;
	height = h;
}

void HandleMouseButton(int button, int state, int x, int y)
{
	int eventType = NA;
	
	if (state == GLUT_DOWN)
	{
		if (button == GLUT_LEFT_BUTTON) eventType = EVENT_MOUSE_DOWN_LEFT;
		else if (button == GLUT_MIDDLE_BUTTON) eventType = EVENT_MOUSE_DOWN_MIDDLE;
		else if (button == GLUT_RIGHT_BUTTON) eventType = EVENT_MOUSE_DOWN_RIGHT;
	}
	else if (state == GLUT_UP)
	{
		if (button == GLUT_LEFT_BUTTON) eventType = EVENT_MOUSE_UP_LEFT;
		else if (button == GLUT_MIDDLE_BUTTON) eventType = EVENT_MOUSE_UP_MIDDLE;
		else if (button == GLUT_RIGHT_BUTTON) eventType = EVENT_MOUSE_UP_RIGHT;
	}
	
	Event newEvent(eventType, x, y);
	events->AddEvent(newEvent);
}

void HandleMouseMotion(int x, int y)
{
	Event newEvent(EVENT_MOUSE_MOTION, x, y);
	events->AddEvent(newEvent);
}

void HandlePassiveMouseMotion(int x, int y)
{
	Event newEvent(EVENT_MOUSE_MOTION, x, y);
	events->AddEvent(newEvent);
}

void HandleKeyPress(unsigned char key, int x, int y)
{
	switch(key)
	{
		case 27:  // Escape key
			exit(0);
			break;
		
		case 127:
		{
			Event newEvent(EVENT_KEYBOARD_K_DEL, NA, NA);
			events->AddEvent(newEvent);
			break;
		}
		
		case '\t':
		{
			Event newEvent(EVENT_KEYBOARD_K_TAB, NA, NA);
			events->AddEvent(newEvent);
			break;
		}
		
		default:
		{
			int eventType;
			
			// 7 onwards = key events
			if (key > 64 && key < 91)  // Uppercase
			{
				eventType = (key - 65) + 7;
			}
			else if (key > 96 && key < 123)  // Lowercase
			{
				eventType = (key - 97) + 7;
			}
			else break;
			
			Event newEvent(eventType, NA, NA);
			events->AddEvent(newEvent);
			break;
		}
	}
}

void HandleSpecialKeyPress(int key, int x, int y)
{
	switch(key)
	{
		default:
			break;
	}
}

void DrawScene()
{
	glClear(GL_COLOR_BUFFER_BIT);
	
	objectDisplay->DrawObjects();
	
	glutSwapBuffers();
}

void Update(int value)
{
	events->ProcessQueue();
	objectDisplay->Update();
	glutPostRedisplay();
	glutTimerFunc((int)(1000.0 / 30.0), Update, 0);
}


int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	
	glutInitWindowSize(width, height);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("ExeSketch");
	
	InitRendering();
	
	objectDisplay = new ObjectDisplay();
	events = new EventHandler(objectDisplay);
	
	ObjectManager* man1 = new ObjectManager();
	objectDisplay->AddClient(man1);
	events->RegisterClient(man1);
	
	glutDisplayFunc(DrawScene);
	glutReshapeFunc(WindowResize);
	glutMouseFunc(HandleMouseButton);
	glutMotionFunc(HandleMouseMotion);
	glutPassiveMotionFunc(HandlePassiveMouseMotion);
	glutKeyboardFunc(HandleKeyPress);
	glutSpecialFunc(HandleSpecialKeyPress);
	
	glutTimerFunc(25, Update, 0);
	
	glutMainLoop();
	
		return 0;
}
