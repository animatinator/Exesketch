// main.h

#ifndef MAIN_H
#define MAIN_H

enum STATE {OBJECT_VIEW = 0, EDITING};

#include "vector2d.h"
#include "event.h"
#include "object.h"
#include "objectdisplay.h"
#include "objectmanager.h"

#endif
