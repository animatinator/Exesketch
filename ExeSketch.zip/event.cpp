// Event.cpp


#include "event.h"
#include "objectdisplay.h"


Event::Event(int eType, int x, int y):
	type(eType),
	xpos(x),
	ypos(y)
{}

Event::Event(const Event& other):
	type(other.type),
	xpos(other.xpos),
	ypos(other.ypos)
{}

ostream& operator<<(ostream& os, const Event& event)
{
	os << "Event of type " << event.type;
	
	if (event.xpos != NA && event.ypos != NA)
	{
		os << ", (" << event.xpos << ", " << event.ypos << ").";
		os << " Real co-ordinates: (" << event.realxpos << ", " << event.realypos << ").";
	}
	else
	{
		os << ".";
	}
	
		return os;
}


EventHandler::EventHandler(ObjectDisplay* screen, const vector<ObjectManager*>& objects)
{
	clients.reserve(objects.size());
	
	for (vector<ObjectManager*>::const_iterator iter = objects.begin(); iter != objects.end(); ++iter)
	{
		clients.push_back(*iter);
	}
	
	display = screen;
}

void EventHandler::RegisterClient(ObjectManager* client)
{
	clients.push_back(client);
}

void EventHandler::ProcessQueue()
{
	Event currentEvent;
	
	while (!eventQueue.empty())
	{
		currentEvent = eventQueue.front();
		
		int type = currentEvent.type;
		
		if (type == EVENT_MOUSE_DOWN_LEFT || type == EVENT_MOUSE_DOWN_MIDDLE || type == EVENT_MOUSE_DOWN_RIGHT)
		{
			bool hit = false;
			
			for (vector<ObjectManager*>::const_iterator iter = clients.begin(); iter != clients.end(); ++iter)
			{
				if ((*iter)->MouseHitObject(currentEvent.xpos, currentEvent.ypos))
				{
					(*iter)->HandleEvent(currentEvent);
					hit = true;
					break;
				}
			}
			
			if (!hit)
			{
				display->HandleEvent(currentEvent);
			}
		}
		else
		{
			for (vector<ObjectManager*>::const_iterator iter = clients.begin(); iter != clients.end(); ++iter)
			{
				(*iter)->HandleEvent(currentEvent);
			}
			
			display->HandleEvent(currentEvent);
		}
		
		eventQueue.pop();
	}
}

void EventHandler::EmptyQueue()
{
	while (!eventQueue.empty())
	{
		eventQueue.pop();
	}
}

void EventHandler::AddEvent(Event& event)
{
	Vector2d offset = display->GetOffset();
	float zoomFactor = display->GetZoom();
	
	if (event.xpos != NA && event.ypos != NA)
	{
		event.realxpos = (int)((float)event.xpos / zoomFactor); event.realypos = (int)((float)event.ypos / zoomFactor);
		event.realxpos = event.realxpos + (int)(offset.x * zoomFactor); event.realypos = event.realypos + (int)(offset.y * zoomFactor);
	}
	
	eventQueue.push(event);
}
