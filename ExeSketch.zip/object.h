// object.h


#ifndef OBJECT_H
#define OBJECT_H

#include "vector2d.h"
#include "event.h"
#include "objectmanager.h"


class Object
{
	public:		
		virtual void Draw() = 0;
		virtual void HandleEvent(const Event& event);
		virtual bool MouseHitObject(int x, int y);
	
	protected:
		Vector2d pos, oldPos;
		int state;
		bool selected, dragging;
		Vector2d storedMouse;
};

#endif
