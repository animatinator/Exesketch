// object.cpp

#include "object.h"
