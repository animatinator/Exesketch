// objectmanager.h


#ifndef OBJECTMANAGER_H
#define OBJECTMANAGER_H

#include <vector>

#include "object.h"
#include "event.h"

using namespace std;


class Object;
class Event;


class ObjectManager
{
	public:
		ObjectManager(const vector<Object*>& newObjects = vector<Object*>());
		~ObjectManager();
		
		void Draw() const;
		void HandleEvent(const Event& event);
		void AddObject(Object* newObject) {objects.push_back(newObject);}
		bool MouseHitObject(int x, int y);
	
	private:
		vector<Object*> objects;
		int state;
};

#endif
