// objectdisplay.cpp


#include "objectdisplay.h"


ObjectDisplay::ObjectDisplay():
	zoomFactor(1.0f),
	offset(0.0f, 0.0f),
	storedMouse(0.0f, 0.0f),
	dragging(false),
	zooming(false)
{}

ObjectDisplay::ObjectDisplay(const vector<ObjectManager*>& startClients):
	clients(startClients),
	zoomFactor(1.0f),
	offset(0.0f, 0.0f),
	storedMouse(0.0f, 0.0f),
	dragging(false),
	zooming(false)
{}

ObjectDisplay::ObjectDisplay(const ObjectDisplay& other):
	clients(other.clients),
	zoomFactor(other.zoomFactor),
	offset(other.offset),
	storedMouse(other.storedMouse),
	dragging(other.dragging),
	zooming(other.zooming)
{}

void ObjectDisplay::DrawObjects() const
{
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(0.375f, 0.375f, 0.0f);
	
	glScalef(zoomFactor, zoomFactor, 0.0f);
	glTranslatef((-offset.x)*zoomFactor, (-offset.y)*zoomFactor, 0.0f);
	
	for (vector<ObjectManager*>::const_iterator iter = clients.begin(); iter != clients.end(); ++iter)
	{
		(*iter)->Draw();
	}
}

void ObjectDisplay::HandleEvent(const Event& event)
{
	if (event.type == EVENT_MOUSE_DOWN_MIDDLE)
	{
		if (!dragging)
		{
			storedMouse = Vector2d(event.xpos, event.ypos);
			zooming = true;
			oldZoomFactor = zoomFactor;
		}
	}
	else if (event.type == EVENT_MOUSE_UP_MIDDLE)
	{
		zooming = false;
	}
	else if (event.type == EVENT_MOUSE_DOWN_LEFT)
	{
		if (!zooming)
		{
			storedMouse = Vector2d(event.xpos, event.ypos);
			dragging = true;
			oldOffset = offset;
		}
	}
	else if (event.type == EVENT_MOUSE_UP_LEFT)
	{
		dragging = false;
	}
	else if (event.type == EVENT_MOUSE_MOTION)
	{
		currentMouse.x = event.xpos;
		currentMouse.y = event.ypos;
		
		if (dragging)
		{
			offset = oldOffset + ((storedMouse - currentMouse) / zoomFactor);
		}
	}
}

void ObjectDisplay::Update()
{
	if (zooming)
	{
		zoomFactor *= 1.0f + (oldZoomFactor * ((currentMouse.y - storedMouse.y) / 100.0f));
	}
}
