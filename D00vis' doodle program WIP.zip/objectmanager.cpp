// objectmanager.cpp


#include "objectmanager.h"


ObjectManager::ObjectManager(const vector<Object*>& newObjects)
{
	for (vector<Object*>::const_iterator iter = newObjects.begin(); iter != newObjects.end(); ++iter)
	{
		objects.push_back(*iter);
	}
}

ObjectManager::~ObjectManager()
{
	for (vector<Object*>::const_iterator iter = objects.begin(); iter != objects.end(); ++iter)
	{
		delete(*iter);
	}
}

void ObjectManager::Draw() const
{
	for (vector<Object*>::const_iterator iter = objects.begin(); iter != objects.end(); ++iter)
	{
		(*iter)->Draw();
	}
}

void ObjectManager::HandleEvent(const Event& event)
{
	EVENT_TYPE type = event.type;
	
	if (type == EVENT_MOUSE_DOWN_LEFT || type == EVENT_MOUSE_DOWN_MIDDLE || type == EVENT_MOUSE_DOWN_RIGHT)
	{
		for (vector<Object*>::const_iterator iter = objects.begin(); iter != objects.end(); ++iter)
		{
			if ((*iter)->MouseHitObject(event.xpos, event.ypos))
			{
				(*iter)->HandleEvent(event);
				break;
			}
		}
	}
	else
	{
		for (vector<Object*>::const_iterator iter = objects.begin(); iter != objects.end(); ++iter)
		{
			(*iter)->HandleEvent(event);
		}
	}
}

bool ObjectManager::MouseHitObject(int x, int y)
{
	for (vector<Object*>::const_iterator iter = objects.begin(); iter != objects.end(); ++iter)
	{
		if ((*iter)->MouseHitObject(x, y))
		{
			return true;
		}
	}
	
	return false;
}
